module.exports = {
  db: {
    uri: process.env.DB_CONNECTION || 'mongodb://localhost:27017/medsystem?readPreference=primary'
  }
};